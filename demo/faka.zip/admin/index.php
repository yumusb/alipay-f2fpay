<?php

/**
 * 后台管理中心
 **/

$title = '后台管理';
include './head.php';
$r1 = $DB->count("SELECT COUNT(id) from faka_order");
$r2 = $DB->count("SELECT COUNT(id) from faka_order  where sta = 1");
$r3 = $DB->count("select COUNT(id) from faka_km");
$r4 = $DB->count("SELECT COUNT(id) from faka_km  where stat = 0");
$r5 = $DB->count("SELECT COUNT(id) from faka_km  where stat = 1");
$r6 = $DB->count("select COUNT(id) from faka_order where YEAR(benTime) = YEAR(NOW()) and  day(benTime) = day(NOW()) and MONTH(benTime) = MONTH(now())");
$r7 = $DB->count("select SUM(money) from faka_order where YEAR(benTime) = YEAR(NOW()) and  day(benTime) = day(NOW()) and MONTH(benTime) = MONTH(now()) and sta = 1");
?>
<div class="container" style="padding-top:70px;">
	<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<h3 class="panel-title">后台管理首页</h3>
			</div>
			<ul class="list-group">
				<li class="list-group-item"><span class="glyphicon glyphicon-tint"></span> <b></b>
				订单总数:<?php echo $r1 ?>&nbsp;&nbsp;
				交易完成:<?php echo $r2 ?>&nbsp;&nbsp;
				今日订单数:<?php echo $r6 ?>&nbsp;&nbsp;
				今日成交金额:<?php if ($r7 != "") {echo round($r7, 2);} else {echo "0";}; ?>￥
				</li>
				<li class="list-group-item"><span class="glyphicon glyphicon-tint"></span> <b></b>卡密总数:<?php echo $r3 ?> 　剩余:<?php echo $r4 ?>　已卖出:<?php echo $r5 ?>
				</li>
				<li class="list-group-item"><span class="glyphicon glyphicon-time"></span> <b>现在时间：</b><?php echo date("Y-m-d H:i") ?> </li>
				<li class="list-group-item"><span class="glyphicon glyphicon-home"></span><a href="./list.php" class="btn btn-xs btn-success">订单管理</a>&nbsp;<a href="./kmlist.php" class="btn btn-xs btn-warning">卡密管理</a>
				</li>
			</ul>
		</div>
		<div class="panel panel-info">
			<div class="panel-heading">
				<h3 class="panel-title">网站信息</h3>
			</div>
			<ul class="list-group">
				<li class="list-group-item">
					<b>当前网站名称：</b><?php echo $conf['title'] ?>
				</li>
				<li class="list-group-item">
					<b>网站客服QQ：</b><?php echo $conf['zzqq'] ?>
				</li>
				<li class="list-group-item">
					<b>注意：</b>开启防腾讯检测可能会造成回调失败 谨慎开启！
				</li>
				<li class="list-group-item">
					<b>作者博客 : </b><a href="http://huai.pub/" target="_blank">http://huai.pub/</a>
				</li>
				<li class="list-group-item">
					<b>程序开发/网站建设/技术支持(付费)：</b> <b id="copyright">QQ1871241891</b>
				</li>
			</ul>
		</div>
	</div>
</div>