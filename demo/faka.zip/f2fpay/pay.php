<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>正在为您跳转到支付页面，请稍候...</title>
    <style type="text/css">
        body {margin:0;padding:0;}
        p {position:absolute;
            left:50%;top:50%;
            width:330px;height:30px;
            margin:-35px 0 0 -160px;
            padding:20px;font:bold 14px/30px "宋体", Arial;
            background:#f9fafc url(../assets/load.gif) no-repeat 20px 26px;
            text-indent:22px;border:1px solid #c5d0dc;}
        #waiting {font-family:Arial;}
    </style>
</head>
<body>

<?php

require_once './f2fpay/model/builder/AlipayTradePrecreateContentBuilder.php';
require_once './f2fpay/service/AlipayTradeService.php';
if($conf['alipay_public_key']==1){
    exit("未初始化支付账号！");
}
@header('Content-Type: text/html; charset=UTF-8');

$type=isset($_GET['type'])?$_GET['type']:exit('No type!');


if($type=='alipay'){

	$or = daddslashes($_GET['out_trade_no']);
	//防止修改价格
	$sql = "SELECT * FROM faka_order WHERE out_trade_no='{$or}' limit 1";
	$row = $DB->get_row($sql);
	if(!$row || $row['money'] != $_GET['money']){
	    exit("验证失败1");
	}
	$sql = "select * from  faka_goods where id = ". daddslashes($_GET['gid']);
	$row = $DB->get_row($sql);
	if(!$row || $row['price'] != $_GET['money']){
	    exit("验证失败2");
    }
}




$outTradeNo = $or; //生成订单账号。要保证唯一性。可以改用其他更符合自己的算法。
$totalAmount = $_GET['money']; //支付宝金额只支持两位小数
if (!is_numeric($totalAmount) || $totalAmount == 0) {
    exit("订单金额不合法!");
}
$body = htmlentities(trim($_GET['name']));
if (strlen($body) > 20) {
    exit("备注太长");
}


// 创建请求builder，设置请求参数
$qrPayRequestBuilder = new AlipayTradePrecreateContentBuilder();
$qrPayRequestBuilder->setOutTradeNo($outTradeNo);
$qrPayRequestBuilder->setTotalAmount($totalAmount);
$qrPayRequestBuilder->setSubject($body);
$qrPay = new AlipayTradeService($alipay_config);
$qrPayResult = $qrPay->qrPay($qrPayRequestBuilder);

if ($qrPayResult->getTradeStatus() === "SUCCESS") {
    $qr = $qrPayResult->getResponse()->qr_code; //SUCCESS 是官方SDK给的结果。如果想看详细的介绍，去找SDK
} else {
    exit('生成订单失败,错误原因：' . $qrPayResult->getTradeStatus());
}
$form['body'] = $body;
$form['no'] = $outTradeNo;
$form['money'] = $totalAmount;
$form['qr'] = $qr;

$sHtml = "<form id='alipaysubmit' name='alipaysubmit' action='./pay/' method='POST'>";

while (list($key, $val) = each($form)) {
    if ($val!=null) {
        //$val = $this->characet($val, $this->postCharset);
        $val = str_replace("'", "&apos;", $val);
        //$val = str_replace("\"","&quot;",$val);
        $sHtml .= "<input type='hidden' name='" . $key . "' value='" . $val . "'/>";
    }
}

//submit按钮控件请不要含有name属性
$sHtml = $sHtml . "<input type='submit' value='ok' style='display:none;''></form>";

$sHtml = $sHtml . "<script>document.forms['alipaysubmit'].submit();</script>";

exit($sHtml);