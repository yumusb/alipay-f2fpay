<?php
/*
 * @Author: yumusb
 * @Date: 2019-08-19 17:49:27
 * @LastEditors: yumusb
 * @LastEditTime: 2019-08-26 12:50:07
 * @Description: 
 */
include '../common/common.php';
header("Content-type: text/html; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    exit();
}
$out_trade_no = trim($_POST['no']);
$sql = "SELECT * FROM faka_order WHERE out_trade_no='{$out_trade_no}' limit 1";
$res = $DB->query($sql);
$srow = $DB->fetch($res);
$res1['status']=(string)$srow['sta'];
exit(json_encode($res1));