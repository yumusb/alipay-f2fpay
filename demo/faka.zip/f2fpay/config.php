<?php
/*
 * @Author: yumusb
 * @Date: 2019-08-19 17:35:15
 * @LastEditors: yumusb
 * @LastEditTime: 2019-08-26 12:51:06
 * @Description: 
 */
include '../common/common.php';
header("Content-type: text/html; charset=utf-8");
function exitt($a = "错误", $b = "../")
{

	echo "<script>alert('{$a}');window.location.href='{$b}'</script>";
	exit();
}

$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url = dirname($http_type . $_SERVER['HTTP_HOST'] . $_SERVER["REQUEST_URI"]) . "/notify.php";

$alipay_config = array(
	//签名方式,默认为RSA2(RSA2048)
	'sign_type' => "RSA2",

	//支付宝公钥
	'alipay_public_key' => trim($conf['alipay_public_key']),

	//商户私钥
	'merchant_private_key' => trim($conf['merchant_private_key']),

	//编码格式
	'charset' => "UTF-8",

	//支付宝网关
	'gatewayUrl' => trim("https://openapi.alipay.com/gateway.do"),

	//应用ID
	'app_id' => $conf['app_id'],
	//最大查询重试次数
	'MaxQueryRetry' => "10",
	'notify_url' => trim($url),
	//查询间隔
	'QueryDuration' => "3"
);