<?php
/*
 * @Author: yumusb
 * @Date: 2019-08-19 17:50:15
 * @LastEditors: yumusb
 * @LastEditTime: 2019-08-26 13:28:00
 * @Description: 
 */

//error_reporting(0);

if (isset($_GET['check'])) {
	exit("notify is OK");
}
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
	exit("ok");
}
require_once './f2fpay/model/builder/AopClient.php';
require_once './config.php';

$aop = new AopClient;
$aop->alipayrsaPublicKey = $alipay_config['alipay_public_key'];
$flag = $aop->rsaCheckV1($_POST, NULL, "RSA2");
if ($flag) {
	
	//异步SIGN验证成功， 可以进行下一步动作。例如验证订单金额 然后完成订单。之类的。。
	//需要验证的就是 订单号 与 订单金额是否一致，验证成功 就可以对数据库中的订单进行操作了。
	//TRADE_SUCCESS 对于当面付来说，已经到账了。详情可以看这里 https://www.cnblogs.com/tdalcn/p/5956690.html
	if ($_POST['trade_status'] === "TRADE_SUCCESS") {
		//订单处理模板
		$no = $_POST['out_trade_no'];
		$mount = $_POST['total_amount'];
		$trade_no  = $_POST['trade_no'];
		$notify_time = $_POST['notify_time'];
		$buyer_logon_id = $_POST['buyer_logon_id'];
		$sql = "SELECT * FROM faka_order WHERE out_trade_no='{$no}' limit 1";
		$res = $DB->query($sql);
		$srow = $DB->fetch($res);
		if ($srow['sta'] === '0') {
			$sql = "update faka_order set sta = 1, trade_no = '{$trade_no}' ,endTime = now() where out_trade_no = '{$no}'";
			$sql2 = "UPDATE faka_km set endTime = now(),out_trade_no = '{$no}',trade_no='{$trade_no}',rel ='{$srow['rel']}',stat = 1 where gid = {$srow['gid']} and stat = 0 limit  1";
			$DB->query($sql);
			$DB->query($sql2);
echo 'success'; //接口必须返回success 不然阿里会一直发送校验验证。
		}else{
echo 'error';
}

	}
} else {
	echo 'error';
}